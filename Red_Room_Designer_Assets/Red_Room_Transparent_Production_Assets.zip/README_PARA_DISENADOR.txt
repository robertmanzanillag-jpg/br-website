RED ROOM — ARTES PARA PRODUCCIÓN

Contenido:
- Broken_Glass_Front.png
- Broken_Glass_Back.png
- Drape_Rect_Front.png
- Drape_Rect_Back.png
- Melt_Front.png
- Melt_Back.png
- Splatter_Front.png
- Splatter_Back.png

Especificaciones:
- Formato PNG con transparencia real (canal alfa).
- Resolución: 4500 × 4500 px.
- Metadata: 300 DPI.
- Frente y espalda están separados.
- No usar las imágenes de mockup como arte de impresión.

Recomendación:
Verificar el tamaño físico final sobre el patrón de cada prenda antes de imprimir.
Para Drape Rect y Melt, usar DTG/DTF o preparar separaciones en medios tonos
si se imprimirá mediante serigrafía.
